import React from 'react'
import ReactDOM from 'react-dom'
import Simple from './src/stories/Simple'

ReactDOM.render(<Simple />, document.getElementById('app'))
